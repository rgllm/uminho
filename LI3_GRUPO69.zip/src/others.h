#include <unistd.h>
#include <termios.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char getch();
void carregaArt(char *nome_ficheiro);
char *my_strdup(const char *s);
int max( int a, int b);

