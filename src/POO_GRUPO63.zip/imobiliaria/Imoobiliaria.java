
public class Imoobiliaria{
    /**
    * Aplicação deverá estar pré-populada com conjunto de dados
    * significativos, que permita testar toda a aplicação no dia da entrega
    */

    public static void initApp (){

    }

    /**
    * Registar um utilizador, quer vendedor, quer comprador
    */
    public void registarUtilizador (Utilizador utilizador) throws UtilizadorExistenteException{

    }

    /**
    * Validar o acesso à aplicação utilizando as credenciais (email e password)
    */
    public void iniciaSessao ( String email , String password ) throws SemAutorizacaoException{

    }

    /**
    * Fechar a sessão do utilizador
    */
    public void fechaSessao (){

    }

}